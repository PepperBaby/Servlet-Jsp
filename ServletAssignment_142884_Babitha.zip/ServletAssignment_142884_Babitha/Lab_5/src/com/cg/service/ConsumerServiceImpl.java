package com.cg.service;

import com.cg.dao.ConsumerDao;
import com.cg.dao.ConsumerDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;

public class ConsumerServiceImpl implements ConsumerService{

	ConsumerDao conDao = null;
	
	
	public ConsumerServiceImpl() {
		super();
		conDao = new ConsumerDaoImpl();
	}
	@Override
	public String getDetails(Consumers consumer) throws BillException {
		return conDao.getDetails(consumer);
	}
	@Override
	public int setBillDetails(BillDetails billDet,Consumers consumer) throws BillException {
		return conDao.setBillDetails(billDet, consumer);
	}

}
