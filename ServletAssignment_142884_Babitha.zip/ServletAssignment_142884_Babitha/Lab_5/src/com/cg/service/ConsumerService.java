package com.cg.service;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;

public interface ConsumerService {
	public String getDetails(Consumers consumer) throws BillException;
	public int setBillDetails(BillDetails billDet,Consumers consumer) throws BillException;
}
