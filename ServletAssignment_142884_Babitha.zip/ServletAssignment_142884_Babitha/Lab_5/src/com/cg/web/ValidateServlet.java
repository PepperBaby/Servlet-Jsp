package com.cg.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.exception.BillException;

@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ValidateServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws 
			ServletException, IOException {
		
		String unm = request.getParameter("txtName");
		String pwd = request.getParameter("txtPwd");

		try 
		{
			
			if((unm.equals("admin")) && (pwd.equals("admin"))) //not case sensitive
			{
				response.sendRedirect("/Lab_5/html/Bill.jsp");
			}
			else
			{
				throw new BillException("Please enter valid Id and Password");
			}
			
		} 
		catch (BillException e)
		{
			
			request.setAttribute("ErrorMsgObj", e.getMessage());
			RequestDispatcher rdError = request.getRequestDispatcher("ErrorPage");
			rdError.forward(request, response);
			
		}
		}
}

