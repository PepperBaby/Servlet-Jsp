package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.Register;



public interface RegistrationDao {

	public int updateDetails(Register reg) throws SQLException;
}
