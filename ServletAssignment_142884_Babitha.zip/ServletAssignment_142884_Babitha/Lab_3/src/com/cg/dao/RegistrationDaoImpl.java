package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Register;
import com.cg.util.DBUtil;

public class RegistrationDaoImpl implements RegistrationDao{
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs =null;
	
	@Override
	public int updateDetails(Register reg) throws SQLException {
		int data;
		con = DBUtil.getCon();
		System.out.println("Got Connection: ");
		String qry ="INSERT INTO registeredUsers values(?,?,?,?,?,?)";
		pst=con.prepareStatement(qry);
		pst.setString(1, reg.getFirstName());
		pst.setString(2, reg.getLastName());
		pst.setString(3, reg.getPassword());
		//String gen =  reg.getGender();
		//String g = gen.charAt(0);
		pst.setString(4, reg.getGender());
		pst.setString(5, reg.getSkill());
		pst.setString(6, reg.getCity());

		data=pst.executeUpdate();
		
		return data;
	}
	
}
