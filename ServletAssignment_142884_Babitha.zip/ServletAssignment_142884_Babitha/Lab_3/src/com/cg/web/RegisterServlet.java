package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;


import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Register;
import com.cg.service.RegistrationService;
import com.cg.service.RegistrationServiceImpl;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RegistrationService regSer = null;
	Register reg = null;
    public RegisterServlet() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		regSer = new RegistrationServiceImpl();
		reg = new Register();
		PrintWriter out = response.getWriter();

		String fName = request.getParameter("txtFirst");
		String lName = request.getParameter("txtLast");
		String pwd = request.getParameter("txtPwd");
		String gen = request.getParameter("gender");
		String skill[] = request.getParameterValues("skills");
		String loc = request.getParameter("location");

		String skills = String.join(",", skill);
		
		reg.setFirstName(fName);
		reg.setLastName(lName);
		reg.setPassword(pwd);
		reg.setGender(gen);
		reg.setSkill(skills);
		reg.setCity(loc);
		
		try 
		{
			if(regSer.updateDetails(reg) == 1)
			{
				response.sendRedirect("/Lab_3.2/Success.html");
			}
			else
			{
				response.sendRedirect("/Lab_3.2/Failure.html");
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
