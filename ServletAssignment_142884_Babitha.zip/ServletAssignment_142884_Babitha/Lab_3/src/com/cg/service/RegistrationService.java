package com.cg.service;

import java.sql.SQLException;

import com.cg.dto.Register;

public interface RegistrationService {
	public int updateDetails(Register reg) throws SQLException;

}
