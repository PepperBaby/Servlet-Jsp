package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.RegistrationDao;
import com.cg.dao.RegistrationDaoImpl;
import com.cg.dto.Register;

public class RegistrationServiceImpl implements RegistrationService {

	RegistrationDao regDao = null;
	
	public RegistrationServiceImpl() {
		super();
		regDao = new RegistrationDaoImpl();
	}

	@Override
	public int updateDetails(Register reg) throws SQLException {
		
		return regDao.updateDetails(reg);
	}

}
