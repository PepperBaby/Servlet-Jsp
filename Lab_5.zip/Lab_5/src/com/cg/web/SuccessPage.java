package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;
import com.cg.service.ConsumerService;
import com.cg.service.ConsumerServiceImpl;


@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SuccessPage() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		HttpSession ses=request.getSession(true);
		BillDetails billDet = new BillDetails();
		ConsumerService conSer = new ConsumerServiceImpl();
		Consumers consumer = new Consumers();
		
		String id=(String) ses.getAttribute("ObjNo");
		String lastRead=(String) ses.getAttribute("ObjLast");
		String currRead=(String) ses.getAttribute("ObjCurr");
		String name=(String) ses.getAttribute("ObjName");
		
		long consumerNo = Long.parseLong(id);
		double current=Double.parseDouble(currRead);
		double last=Double.parseDouble(lastRead);
		
		try 
		{
			if(last >= current)
			{
			double unitConsumed=last-current;
			double fixedChardge=100;
			double netAmount=unitConsumed*1.15 +fixedChardge;
			
			consumer.setConsumerNo(consumerNo);
			billDet.setCurrReading(current);
			billDet.setUnitConsumed(unitConsumed);
			billDet.setNetAmount(netAmount);
			
			int data = conSer.setBillDetails(billDet,consumer);
			
				if(data == 1)
				{
				System.out.println("Bill Details Inserted");

				out.print("<h3>Welcome "+name+"</h3>");
				out.print("<h1>Electricity Bill for Consumer Number - "+id+" is </h1>");
				out.print("<h2>Unit Consumed :: "+unitConsumed+"</h2>");
				out.print("<h2>Net Amount :: Rs. "+netAmount+"</h2>");
				}
				else
				{
					System.out.println("Failed to insert details");
				}
			}
			else
			{ 
				String msg = "Current Month meter reading is greator than Last Month meter reading";
				request.setAttribute("ErrorMsgObj", msg);
				RequestDispatcher rdError = request.getRequestDispatcher("ErrorPage");
				rdError.forward(request, response);
				throw new BillException("Current Month meter reading is greator than Last Month meter reading");
			}
			
		}
		catch (BillException e) 
		{
			e.printStackTrace();
		}

}

}
