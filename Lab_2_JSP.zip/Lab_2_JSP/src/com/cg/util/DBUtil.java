package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.EBillException;



public class DBUtil {

	private static Connection conn;
	public static Connection getConnection() throws EBillException{
		if(conn==null)
		{
			InitialContext ic;
			try 
			{
				ic = new InitialContext();
				DataSource ds =(DataSource) ic.lookup("java:/jdbc/OracleDS");
				conn = ds.getConnection();
			} 
			catch (NamingException e) 
			{
				throw new EBillException("Problem in Obtaining Datasource: "+e.getMessage());	
			}
			catch (SQLException e) 
			{
				throw new EBillException("Problem in Obtaining connection from Datasource: "+e.getMessage());
			}
		}
		return conn;
	}
}
