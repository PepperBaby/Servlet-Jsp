package com.cg.dto;

public class Consumers {

	private long consumerNo;
	private String consumerName;
	private String consumerAdd;
	
	public long getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(long consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getConsumerAdd() {
		return consumerAdd;
	}
	public void setConsumerAdd(String consumerAdd) {
		this.consumerAdd = consumerAdd;
	}
	public Consumers() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Consumers(long consumerNo, String consumerName, String consumerAdd) {
		super();
		this.consumerNo = consumerNo;
		this.consumerName = consumerName;
		this.consumerAdd = consumerAdd;
	}
	@Override
	public String toString() {
		return "Consumers [consumerNo=" + consumerNo + ", consumerName="
				+ consumerName + ", consumerAdd=" + consumerAdd + "]";
	}
	
}
