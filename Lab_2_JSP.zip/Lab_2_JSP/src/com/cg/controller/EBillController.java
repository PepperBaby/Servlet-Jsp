package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;

@WebServlet(urlPatterns={"/list","/search","/billdetail","/home","/showconsumer","/userinput","/success"})
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public EBillController() {
        super();
        
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getServletPath();
		String targetUrl = "";
		EBillService ebillSer = new EBillServiceImpl();
		switch(url)
		{
		case "/list":
			HttpSession sess = request.getSession(true);
			try 
			{
				List<Consumers> cList = ebillSer.getAllConsumers();
				
				sess.setAttribute("cList", cList);
				targetUrl = "Show_ConsumerList.jsp";	
			}  
			catch (EBillException e) 
			{
				sess.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		case "/search":
			targetUrl = "Search_Consumer.jsp";
			break;
			
		case "/billdetail":
			HttpSession sess1 = request.getSession(false);
			//long conNo = (long) sess1.getAttribute("consumerNo");
			long conNo = Long.parseLong(request.getParameter("consumerNo"));
			try 
			{
				List<BillDetails> bList = ebillSer.getBillDetails(conNo);
				sess1.setAttribute("bList", bList);
			
				targetUrl = "Show_Bills.jsp";
			} 
			catch (EBillException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
			
		case "/home":
			targetUrl = "index.html";
			break;
			
		case "/showconsumer":
		{
			long consumerNo = Long.parseLong(request.getParameter("conNum"));
			
			try 
			{
				Consumers consumer1 = ebillSer.getConsumer(consumerNo);
				HttpSession sess11 = request.getSession(true);
				sess11.setAttribute("consumer", consumer1);
				//sess11.setAttribute("consumerNo", consumer1.getConsumerNo());
	
				targetUrl = "Show_Consumer.jsp";
				
			} 
			catch (EBillException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		
			break;	
		}
		case "/userinput":
			targetUrl="User_Info.jsp";
			break;
			
		case "/success":
			String connNo = request.getParameter("txtNumber");
			String lastMonRead = request.getParameter("txtLast");
			String currMonRead = request.getParameter("txtCurrent");
			long consumerNo = Long.parseLong(connNo);
			double current=Double.parseDouble(currMonRead);
			double last=Double.parseDouble(lastMonRead);
			PrintWriter out=response.getWriter();
			if(last >= current)
			{
			double unitConsumed=last-current;
			double fixedChardge=100;
			double netAmount=unitConsumed*1.15 +fixedChardge;
			
			System.out.println("Bill Details Inserted");

			out.print("<h3>Welcome </h3>");
			out.print("<h1>Electricity Bill for Consumer Number - "+consumerNo+" is </h1>");
			out.print("<h2>Unit Consumed :: "+unitConsumed+"</h2>");
			out.print("<h2>Net Amount :: Rs. "+netAmount+"</h2>");
			}
			break;
		}
		RequestDispatcher disp = request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}

}
