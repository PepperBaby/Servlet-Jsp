package com.cg.dao;

import java.util.List;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;


public interface EBillDao {

	List<Consumers> getAllConsumers() throws EBillException;
	Consumers getConsumer(long consumerNo) throws EBillException;
	long insertBillDetails(BillDetails bDetails) throws EBillException;
	List<BillDetails> getBillDetails(long consumerNo) throws EBillException;
}
